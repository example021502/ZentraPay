package com.zentrapay_application.zentrapay_spring_boot_layer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZentrapaySpringBootLayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
