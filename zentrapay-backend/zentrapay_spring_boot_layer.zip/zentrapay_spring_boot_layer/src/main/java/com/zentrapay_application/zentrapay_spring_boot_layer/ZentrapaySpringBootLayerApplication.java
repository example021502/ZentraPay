package com.zentrapay_application.zentrapay_spring_boot_layer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZentrapaySpringBootLayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZentrapaySpringBootLayerApplication.class, args);
	}

}
